Lettering (white):
f2f2f2

Fields (dark gray):
6b6b6b

Field place holder (light gray):
808080